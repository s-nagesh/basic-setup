module.exports.RoleEnum = () => {
  let RoleEnum = {
    Admin: 1,
    User: 2,
  };
  Object.freeze(RoleEnum);
  return RoleEnum;
};
